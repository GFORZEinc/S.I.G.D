-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 192.168.2.195    Database: Gforze
-- ------------------------------------------------------
-- Server version	5.5.68-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deporte`
--

DROP TABLE IF EXISTS `deporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deporte` (
  `id_deporte` int(11) NOT NULL,
  `nombredeporte` varchar(50) DEFAULT NULL,
  `reglamento` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_deporte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deporte`
--

LOCK TABLES `deporte` WRITE;
/*!40000 ALTER TABLE `deporte` DISABLE KEYS */;
INSERT INTO `deporte` VALUES (1,'futbol','El futbol se juega con los pies'),(2,'handball','El handball se juega con las manos'),(3,'basketball','El basketball se juega con las manos');
/*!40000 ALTER TABLE `deporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo`
--

DROP TABLE IF EXISTS `equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipo` (
  `idequipo` int(11) NOT NULL,
  `nombreEquipo` varchar(50) DEFAULT NULL,
  `descriEquipo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idequipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo`
--

LOCK TABLES `equipo` WRITE;
/*!40000 ALTER TABLE `equipo` DISABLE KEYS */;
INSERT INTO `equipo` VALUES (1,'Barcelona','Jugo Messi'),(2,'Real Madrid','Jugo Cristiano Ronaldo');
/*!40000 ALTER TABLE `equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jugador`
--

DROP TABLE IF EXISTS `jugador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jugador` (
  `idjugador` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `altura` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`idjugador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugador`
--

LOCK TABLES `jugador` WRITE;
/*!40000 ALTER TABLE `jugador` DISABLE KEYS */;
INSERT INTO `jugador` VALUES (1,'Lionel','Messi','170'),(2,'Cristiano','Ronaldo','185');
/*!40000 ALTER TABLE `jugador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partidobasketball`
--

DROP TABLE IF EXISTS `partidobasketball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidobasketball` (
  `id_partido_b` int(11) NOT NULL,
  `fecha_hora_b` datetime DEFAULT NULL,
  `ubicacion_b` varchar(200) DEFAULT NULL,
  `equipoL_b` varchar(100) DEFAULT NULL,
  `resultado_b` varchar(10) DEFAULT NULL,
  `equipoLoV_b` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_partido_b`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidobasketball`
--

LOCK TABLES `partidobasketball` WRITE;
/*!40000 ALTER TABLE `partidobasketball` DISABLE KEYS */;
INSERT INTO `partidobasketball` VALUES (1,'2022-11-08 10:24:28','Antel Arena','Aguada','100-93','Peñarol');
/*!40000 ALTER TABLE `partidobasketball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partidofutbol`
--

DROP TABLE IF EXISTS `partidofutbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidofutbol` (
  `id_partido_f` int(11) NOT NULL,
  `fecha_hora_f` datetime DEFAULT NULL,
  `ubicacion_f` varchar(200) DEFAULT NULL,
  `equipoL_f` varchar(100) DEFAULT NULL,
  `resultado_f` varchar(10) DEFAULT NULL,
  `equipoLoV_f` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_partido_f`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidofutbol`
--

LOCK TABLES `partidofutbol` WRITE;
/*!40000 ALTER TABLE `partidofutbol` DISABLE KEYS */;
INSERT INTO `partidofutbol` VALUES (1,'2022-11-08 10:24:28','Estadio Centenario','Nacional','10-0','Peñarol');
/*!40000 ALTER TABLE `partidofutbol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partidohandball`
--

DROP TABLE IF EXISTS `partidohandball`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidohandball` (
  `id_partido_h` int(11) NOT NULL,
  `fecha_hora_h` datetime DEFAULT NULL,
  `ubicacion_h` varchar(200) DEFAULT NULL,
  `equipoL_h` varchar(100) DEFAULT NULL,
  `resultado_h` varchar(250) DEFAULT NULL,
  `equipoLoV_h` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_partido_h`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidohandball`
--

LOCK TABLES `partidohandball` WRITE;
/*!40000 ALTER TABLE `partidohandball` DISABLE KEYS */;
INSERT INTO `partidohandball` VALUES (1,'2022-11-08 10:24:28','Amtel Arena','Nacional','20-18','Peñarol');
/*!40000 ALTER TABLE `partidohandball` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `idrol` int(11) NOT NULL,
  `rol` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`idrol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'administrador'),(2,'administrativo'),(3,'usuario');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torneo`
--

DROP TABLE IF EXISTS `torneo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `torneo` (
  `id_torneo` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `final` date DEFAULT NULL,
  `deporte` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_torneo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torneo`
--

LOCK TABLES `torneo` WRITE;
/*!40000 ALTER TABLE `torneo` DISABLE KEYS */;
INSERT INTO `torneo` VALUES (1,'Torneo Apertura','2022-02-15','2022-10-30','futbol');
/*!40000 ALTER TABLE `torneo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL DEFAULT '0',
  `ci` int(11) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `contra` varchar(200) DEFAULT NULL,
  `rol` int(11) DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,12345678,'Pepito','Farias','pfarias','pepitofarias@gmail.com','123',1),(2,87654321,'Mauro','Fernandez','mfernandez','maurofernandez@gmail.com','123',2),(3,54935465,'Diego','Vallejos','dvallejos','diegovallejos@gmail.com','123',3);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-08 10:46:07
