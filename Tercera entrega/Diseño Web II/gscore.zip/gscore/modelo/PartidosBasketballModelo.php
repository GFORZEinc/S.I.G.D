<?php

class PartidosBasketball_modelo
{
//Declaramos dos atributos para la conexión
    private $db;
    private $partidosB;

    public function __construct()
    {//Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
     //Inicializo perros como un array vacio.
        $this->partidosB = array();
    }
    // Método que devuelve la información de la tabla.

    public function get_partidosB()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM partidobasketball";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->partidosB[] = $row;
        }
        return $this->partidosB;
    }

    public function insertar($fecha_hora_b, $ubicacion_b, $resultado_b, $equipoL_b, $equipoLoV_b){
			
       $this->db->query("INSERT INTO partidobasketball (fecha_hora_b, ubicacion_b, resultado_b, equipoL_b, equipoLoV_b) VALUES ('$fecha_hora_b', '$ubicacion_b', '$resultado_b', '$equipoL_b', '$equipoLoV_b')");
        
    }
   
    public function modificar($id_partido_b, $fecha_hora_b, $ubicacion_b, $resultado_b, $equipoL_b, $equipoLoV_b){
			
     $this->db->query("UPDATE partidobasketball SET fecha_hora_b='$fecha_hora_b', ubicacion_b='$ubicacion_b', resultado_b='$resultado_b', equipoL_b='$equipoL_b', equipoLoV_b='$equipoLoV_b' WHERE id_partido_b = '$id_partido_b'");			
    }
    
    public function eliminar($id_partido_b){
        
        $this->db->query("DELETE FROM partidobasketball WHERE id_partido_b = '$id_partido_b'");
        
    }
    
    public function get_partidoB($id_partido_b)
    {
        $sql = "SELECT * FROM partidobasketball WHERE id_partido_b='$id_partido_b' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();


        return $row;
    }
} 


?>