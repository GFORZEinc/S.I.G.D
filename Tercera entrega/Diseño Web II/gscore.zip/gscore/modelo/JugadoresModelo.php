<?php

class Jugadores_modelo
{
//Declaramos dos atributos para la conexión
    private $db;
    private $jugadores;

    public function __construct()
    {//Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
     //Inicializo perros como un array vacio.
        $this->jugadores = array();
    }
    // Método que devuelve la información de la tabla.

    public function get_jugadores()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM jugador";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->jugadores[] = $row;
        }
        return $this->jugadores;
    }

    public function insertar($nombre, $apellido, $altura){
			
       $this->db->query("INSERT INTO jugador (nombre, apellido , altura) VALUES ('$nombre', '$apellido', '$altura')");
        
    }
   
    public function modificar($id, $nombre, $apellido, $altura){
			
     $this->db->query("UPDATE jugador SET nombre='$nombre', apellido='$apellido', altura='$altura' WHERE idjugador = '$id'");			
    }
    
    public function eliminar($id){
        
        $this->db->query("DELETE FROM jugador WHERE idjugador = '$id'");
        
    }
    
    public function get_jugador($id)
    {
        $sql = "SELECT * FROM jugador WHERE idjugador='$id' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();


        return $row;
    }
} 


?>