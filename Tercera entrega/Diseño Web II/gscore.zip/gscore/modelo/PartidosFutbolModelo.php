<?php

class PartidosFutbol_modelo
{
//Declaramos dos atributos para la conexión
    private $db;
    private $partidosF;

    public function __construct()
    {//Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
     //Inicializo perros como un array vacio.
        $this->partidosF = array();
    }
    // Método que devuelve la información de la tabla.

    public function get_partidosF()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM partidofutbol";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->partidosF[] = $row;
        }
        return $this->partidosF;
    }

    public function insertar($fecha_hora_f, $ubicacion_f, $resultado_f, $equipoL_f, $equipoLoV_f){
			
       $this->db->query("INSERT INTO partidofutbol (fecha_hora_f, ubicacion_f, resultado_f, equipoL_f, equipoLoV_f) VALUES ('$fecha_hora_f', '$ubicacion_f', '$resultado_f', '$equipoL_f', '$equipoLoV_f')");
        
    }
   
    public function modificar($id_partido_f, $fecha_hora_f, $ubicacion_f, $resultado_f, $equipoL_f, $equipoLoV_f){
			
     $this->db->query("UPDATE partidofutbol SET fecha_hora_f='$fecha_hora_f', ubicacion_f='$ubicacion_f', resultado_f='$resultado_f', equipoL_f='$equipoL_f', equipoLoV_f='$equipoLoV_f' WHERE id_partido_f = '$id_partido_f'");			
    }
    
    public function eliminar($id_partido_f){
        
        $this->db->query("DELETE FROM partidofutbol WHERE id_partido_f = '$id_partido_f'");
        
    }
    
    public function get_partidoF($id_partido_f)
    {
        $sql = "SELECT * FROM partidofutbol WHERE id_partido_f='$id_partido_f' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();


        return $row;
    }
} 


?>