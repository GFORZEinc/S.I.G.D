<?php

class PartidosHandball_modelo
{
//Declaramos dos atributos para la conexión
    private $db;
    private $partidosH;

    public function __construct()
    {//Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
     //Inicializo perros como un array vacio.
        $this->partidosH = array();
    }
    // Método que devuelve la información de la tabla.

    public function get_partidosH()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM partidohandball";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->partidosH[] = $row;
        }
        return $this->partidosH;
    }

    public function insertar($fecha_hora_h, $ubicacion_h, $resultado_h, $equipoL_h, $equipoLoV_h){
			
       $this->db->query("INSERT INTO partidohandball (fecha_hora_h, ubicacion_h, resultado_h, equipoL_h, equipoLoV_h) VALUES ('$fecha_hora_h', '$ubicacion_h', '$resultado_h', '$equipoL_h', '$equipoLoV_h')");
        
    }
   
    public function modificar($id_partido_h, $fecha_hora_h, $ubicacion_h, $resultado_h, $equipoL_h, $equipoLoV_h){
			
     $this->db->query("UPDATE partidohandball SET fecha_hora_h='$fecha_hora_h', ubicacion_h='$ubicacion_h', resultado_h='$resultado_h', equipoL_h='$equipoL_h', equipoLoV_h='$equipoLoV_h' WHERE id_partido_h = '$id_partido_h'");			
    }
    
    public function eliminar($id_partido_h){
        
        $this->db->query("DELETE FROM partidohandball WHERE id_partido_h = '$id_partido_h'");
        
    }
    
    public function get_partidoF($id_partido_h)
    {
        $sql = "SELECT * FROM partidohandball WHERE id_partido_h='$id_partido_h' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();


        return $row;
    }
} 


?>