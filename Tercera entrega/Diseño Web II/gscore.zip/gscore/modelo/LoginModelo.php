<?php

class Login_modelo
{

    private $db;
    private $usuarios;

    public function __construct()
    { 
       
     //Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
        //Inicializo perros como un array vacio.
        $this->usuarios = array();
    }

    public function get_usuarios()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM usuario";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->usuarios[] = $row;
        }
        return $this->usuarios;
    }

    public function insertar($nombre, $apellido, $ci, $usuario, $contra, $correo, $rol )
    {

         $this->db->query("INSERT INTO usuario (nombre, apellido, ci, usuario, contra, correo, rol) VALUES ('$nombre', '$apellido', '$ci', '$usuario', '$contra', '$correo', '$rol')");

    }

    public function modificar($idusuario,$nombre, $apellido, $ci, $usuario, $contra, $correo, $rol)
    {

        $this->db->query("UPDATE usuario SET nombre='$nombre', apellido='$apellido', ci='$ci', usuario='$usuario', contra='$contra', correo='$correo', rol='$rol' WHERE idusuario = '$idusuario'");
    }

    public function eliminar($idusuario)
    {

        $this->db->query("DELETE FROM usuario WHERE idusuario = '$idusuario'");

    }

    public function get_usuario($idusuario)
    {
        $sql = "SELECT * FROM usuario WHERE idusuario='$idusuario' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();

        return $row;
    }

    public function obtenerUsuario($correo, $contra)
    {
        $sql = "SELECT * FROM usuario WHERE correo='$correo'AND contra='$contra'";
        $resultado = $this->db->query($sql);
        $registro = $resultado->fetch_assoc();

        return $registro;
        

    }

}

?>