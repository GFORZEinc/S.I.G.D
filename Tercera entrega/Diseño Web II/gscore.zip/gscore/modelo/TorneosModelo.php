<?php

class Torneos_modelo
{

    private $db;
    private $torneos;

    public function __construct()
    { 
       
     //Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
        //Inicializo perros como un array vacio.
        $this->torneos = array();
    }

    public function get_torneos()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM torneo";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->torneos[] = $row;
        }
        return $this->torneos;
    }

    public function insertar($nombre, $inicio, $final, $deporte)
    {

         $this->db->query("INSERT INTO torneo (nombre, inicio, final, deporte) VALUES ('$nombre', '$inicio', '$final', '$deporte')");

    }

    public function modificar($id_torneo, $nombre, $inicio, $final, $deporte)
    {

        $this->db->query("UPDATE torneo SET nombre='$nombre', inicio='$inicio', final='$final', deporte='$deporte' WHERE id_torneo = '$id_torneo'");
    }

    public function eliminar($id_torneo)
    {

        $this->db->query("DELETE FROM torneo WHERE id_torneo = '$id_torneo'");

    }

    public function get_torneo($id_torneo)
    {
        $sql = "SELECT * FROM torneo WHERE id_torneo='$id_torneo' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();

        return $row;
    }

}

?>