<?php

class Equipos_modelo
{
//Declaramos dos atributos para la conexión
    private $db;
    private $equipos;

    public function __construct()
    {//Operador de Resolución de Ámbito :: hacemos referecia a la clase externa Conectar
        $this->db = Conectar::conexion();
     //Inicializo perros como un array vacio.
        $this->equipos = array();
    }
    // Método que devuelve la información de la tabla.

    public function get_equipos()
    {
        //Consulta sql para seleccionar t
        $sql = "SELECT * FROM equipo";
        $resultado = $this->db->query($sql);
        //Para obtener una fila de resultado como un array asociativo
        while ($row = $resultado->fetch_assoc()) {
            $this->equipos[] = $row;
        }
        return $this->equipos;
    }

    public function insertar($nombreEquipo, $descriEquipo){
			
       $this->db->query("INSERT INTO equipo (nombreEquipo, descriEquipo) VALUES ('$nombreEquipo', '$descriEquipo')");
        
    }
   
    public function modificar($id, $nombreEquipo, $descriEquipo){
			
     $this->db->query("UPDATE equipo SET nombreEquipo='$nombreEquipo', descriEquipo='$descriEquipo' WHERE idequipo = '$id'");			
    }
    
    public function eliminar($id){
        
        $this->db->query("DELETE FROM equipo WHERE idequipo = '$id'");
        
    }
    
    public function get_equipo($id)
    {
        $sql = "SELECT * FROM equipo WHERE idequipo='$id' LIMIT 1";
        $resultado = $this->db->query($sql);
        $row = $resultado->fetch_assoc();


        return $row;
    }
} 


?>