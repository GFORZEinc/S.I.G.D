<?php
//Creamos una conexión de BD
class Conectar
{

    public static function conexion()
    {

        $servername = "192.168.2.195";
        $username = "dvallejos";
        $password = "54935465";
        $database = "Gforze";

        //Parametro de Entrada: Servidor, usuario,pass, base de datos.
        $conexion = new mysqli($servername, $username, $password, $database);
        //Verificamos la conexión
        if ($conexion->connect_error) {
            printf("Conexión fallida: %s\n", $conexion->connect_error);
            exit();
        }

        return $conexion;

    }
}
