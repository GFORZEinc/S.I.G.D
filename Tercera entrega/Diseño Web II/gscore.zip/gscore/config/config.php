<?php
	//Declaro un contante con el fin de crear un controlador por defecto. Podría ser la página de inicio
	define("CONTROLADOR_PRINCIPAL","Login");
	//Declaro la acción por defecto. Index se realizará el control de url inserta por el usuario.
	define("ACCION_PRINCIPAL", "validarLogin");
	
?>