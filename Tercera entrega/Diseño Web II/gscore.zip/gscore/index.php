<?php
require_once "config/bd.php";
require_once "controlador/jugadores.php";
require_once "controlador/equipos.php";
require_once "controlador/torneos.php";
require_once "controlador/partidosF.php";
require_once "controlador/partidosH.php";
require_once "controlador/partidosB.php";
require_once "controlador/inicio.php";
require_once "controlador/usuarios.php";
require_once "controlador/login.php";
require_once "config/config.php";
require_once "core/routes.php";

//La función isset() nos permite evaluar si una variable está definida o no
	
	if(isset($_GET['c'])){
		
		$controlador = cargarControlador($_GET['c']);
		
		if(isset($_GET['a'])){
			if(isset($_GET['id'])){
				cargarAccion($controlador, $_GET['a'], $_GET['id']);
				} else {
				cargarAccion($controlador, $_GET['a']);
			}
			} else {
			cargarAccion($controlador, ACCION_PRINCIPAL);
		}
		
		} else {
		
		$controlador = cargarControlador(CONTROLADOR_PRINCIPAL);
		$accionTmp = ACCION_PRINCIPAL;
		$controlador->$accionTmp();
	}
