<?php
    require_once "modelo/LoginModelo.php";


    class InicioControlador
    {
        public function __construct()
        {
            

            require_once "modelo/JugadoresModelo.php";
        }

        public function mostrarInicio2()
        {


            require_once "vista/inicio/inicio2.html";
        }

        public function mostrarJugadores()
        {
            $jugadores = new Jugadores_modelo();
            $data["titulo"] = "Jugadores Registrados";
            $data["jugadores"] = $jugadores->get_jugadores();


            require_once "vista/jugadores/jugadores.html";
        }

        public function mostrarUsuarios()
        {
            $usuarios = new Login_modelo();
            $data["titulo"] = "Usuarios registrados";
            $data["usuarios"] = $usuarios->get_usuarios();


            require_once "vista/login/usuarios_Agregar.html";
        }
    }
?>