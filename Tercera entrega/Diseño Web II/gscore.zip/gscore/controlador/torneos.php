<?php

    class TorneosControlador  {
        public function __construct()
        {
            

            require_once "modelo/TorneosModelo.php";
        }

        public function mostrarTorneos()
        {
            $torneos = new Torneos_modelo();
            $data["titulo"] = "Torneos Registrados";
            $data["torneo"] = $torneos->get_torneos();


            require_once "vista/torneos/torneos.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Torneos";


            require_once "vista/torneos/torneos_Nuevos.html";
        }

        public function guardar()
        {
            $nombre = $_POST['nombre'];
            $inicio = $_POST['inicio'];
            $final = $_POST['final'];
            $deporte = $_POST['deporte'];
            $torneos = new Torneos_modelo();
            $torneos->insertar($nombre, $inicio, $final, $deporte);
            $data["titulo"] = "Ingresar nuevo torneo";
            $this->mostrarTorneos();
        }

        public function modificar($id)
        {
            $torneo = new Torneos_modelo();
            $dato["id_torneo"] = $id;
            $dato["torneo"] = $torneo->get_torneo($id);
            $dato["titulo"] = "Registro torneos";


            require_once "vista/torneos/torneos_Modificar.html";
        }

        public function actualizar()
        {
            $id = $_POST['id_torneo'];
            $nombre = $_POST['nombre'];
            $inicio = $_POST['inicio'];
            $final = $_POST['final'];
            $deporte = $_POST['deporte'];
            $torneo = new Torneos_modelo();
            $torneo->modificar($id, $nombre, $inicio, $final, $deporte);
            $data["titulo"] = "Torneo";
            $this->mostrarTorneos();
        }

        public function eliminar($id)
        {
            $torneos = new Torneos_modelo();
            $torneos->eliminar($id);
            $data["titulo"] = "Torneo";
            $this->mostrarTorneos();
        }
    }
?>