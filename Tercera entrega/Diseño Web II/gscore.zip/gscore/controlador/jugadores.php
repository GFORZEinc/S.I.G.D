<?php

    class JugadoresControlador  {
        public function __construct()
        {
            

            require_once "modelo/JugadoresModelo.php";
        }

        public function mostrarJugadores()
        {
            $jugadores = new Jugadores_modelo();
            $data["titulo"] = "Jugadores Registrados";
            $data["jugador"] = $jugadores->get_jugadores();


            require_once "vista/jugadores/jugadores.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Jugadores";


            require_once "vista/jugadores/jugadores_Nuevos.html";
        }

        public function guardar()
        {
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $altura = $_POST['altura'];
            $jugadores = new Jugadores_modelo();
            $jugadores->insertar($nombre, $apellido, $altura);
            $data["titulo"] = "Ingresar nuevo jugador";
            $this->mostrarJugadores();
        }

        public function modificar($id)
        {
            $jugador = new Jugadores_modelo();
            $dato["idjugador"] = $id;
            $dato["jugador"] = $jugador->get_jugador($id);
            $dato["titulo"] = "Registro jugadores";


            require_once "vista/jugadores/jugadores_Modificar.html";
        }

        public function actualizar()
        {
            $id = $_POST['idjugador'];
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $altura = $_POST['altura'];
            $jugador = new Jugadores_modelo();
            $jugador->modificar($id, $nombre, $apellido, $altura);
            $data["titulo"] = "Jugador";
            $this->mostrarJugadores();
        }

        public function eliminar($id)
        {
            $jugadores = new Jugadores_modelo();
            $jugadores->eliminar($id);
            $data["titulo"] = "Jugador";
            $this->mostrarJugadores();
        }
    }
?>