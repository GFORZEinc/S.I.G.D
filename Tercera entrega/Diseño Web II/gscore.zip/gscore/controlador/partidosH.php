<?php

    class PartidosHControlador  {
        public function __construct()
        {
            

            require_once "modelo/PartidosHandballModelo.php";
        }

        public function mostrarPartidosH()
        {
            $partidosH = new PartidosHandball_modelo();
            $data["titulo"] = "Partidos Registrados";
            $data["partidohandball"] = $partidosH->get_partidosH();


            require_once "vista/deportes/handball/handball.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Partidos (BALONMANO)";


            require_once "vista/deportes/handball/handball_Nuevos.html";
        }

        public function guardar()
        {
            $fecha_hora_h = $_POST['fecha_hora_h'];
            $ubicacion_h = $_POST['ubicacion_h'];
            $resultado_h = $_POST['resultado_h'];
            $equipoL_h = $_POST['equipoL_h'];
            $equipoLoV_h = $_POST['equipoLoV_h'];
            $partidosH = new PartidosHandball_modelo();
            $partidosH->insertar($fecha_hora_h, $ubicacion_h, $resultado_h, $equipoL_h, $equipoLoV_h);
            $data["titulo"] = "Ingresar nuevo partido";
            $this->mostrarPartidosH();
        }

        public function modificar($id_partido_h)
        {
            $partido = new PartidosHandball_modelo();
            $dato["id_partido_h"] = $id_partido_h;
            $dato["partidohandball"] = $partido->get_partidosH($id_partido_h);
            $dato["titulo"] = "Registro partidos";


            require_once "vista/deportes/handball/handball_Modificar.html";
        }

        public function actualizar()
        {
            $id_partido_h = $_POST['id_partido_h'];
            $fecha_hora_h = $_POST['fecha_hora_h'];
            $ubicacion_h = $_POST['ubicacion_h'];
            $resultado_h = $_POST['resultado_h'];
            $equipoL_h = $_POST['equipoL_h'];
            $equipoLoV_h = $_POST['equipoLoV_h'];
            $partidosH = new PartidosHandball_modelo();
            $partidosH->modificar($id_partido_h, $fecha_hora_h, $ubicacion_h, $resultado_h, $equipoL_h, $equipoLoV_h);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosH();
        }

        public function eliminar($id_partido_h)
        {
            $partidosH = new PartidosHandball_modelo();
            $partidosH->eliminar($id_partido_h);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosH();
        }
    }
?>