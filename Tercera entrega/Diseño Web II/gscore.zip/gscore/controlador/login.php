<?php
        session_start();


class LoginControlador
{

    public function __construct()
    {

        require_once "modelo/LoginModelo.php";

    }

    public function validarLogin()

    {
       // session_start();


        require_once "vista/login/login.html";
        //header('Location: index.php?c=login&a=validarLogin');

        if (!empty($_SESSION['active'])) {
            echo "la sesion fue creada";
            header('Location: index.php?c=Inicio&a=mostrarInicio2');

        } else {

            //isset() devolverá true si hemos definido la variable con anterioridad y si hemos establecido su valor en algo diferente a NULL.
            if (isset($_POST['entrar'])) {
                echo "Ingrese los datos correspondientes en los campos vacíos";

                if (empty($_POST['correo']) || (empty($_POST['contra']))) {
                    $alert = "Ingrese su correo y su contraseña";
                } else {
                    $correo = $_POST['correo'];
                    $contra = $_POST['contra'];
                    $login = new Login_modelo;
                    $registro = $login->obtenerUsuario($correo, $contra);
                    if (isset($registro)) {

                        $_SESSION['active'] = true;
                        $_SESSION['idusuario'] = $registro['idusuario'];
                        $_SESSION['nombre'] = $registro['nombre'];
                        $_SESSION['apellido'] = $registro['apellido'];
                        $_SESSION['ci'] = $registro['ci'];
                        $_SESSION['usuario'] = $registro['usuario'];
                        $_SESSION['contra'] = $registro['contra'];
                        $_SESSION['correo'] = $registro['correo'];
                        $_SESSION['rol'] = $registro['rol'];
                        
                      

                        header('Location: index.php?c=Inicio&a=mostrarInicio2');

                    } else {
                        echo " El usuario o la contraseña son incorrectos";
                        session_destroy();
                    }

                }

            }
        }
    }

    
public function salir(){
 session_destroy();
 require_once "vista/login/login.html";


}
}
