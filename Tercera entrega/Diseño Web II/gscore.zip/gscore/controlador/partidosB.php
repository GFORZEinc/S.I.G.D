<?php

    class PartidosBControlador  {
        public function __construct()
        {
            

            require_once "modelo/PartidosBasketballModelo.php";
        }

        public function mostrarPartidosB()
        {
            $partidosB = new PartidosBasketball_modelo();
            $data["titulo"] = "Partidos Registrados";
            $data["partidobasketball"] = $partidosB->get_partidosB();


            require_once "vista/deportes/basketball/basketball.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Partidos (BALONCESTO)";


            require_once "vista/deportes/basketball/basketball_Nuevos.html";
        }

        public function guardar()
        {
            $fecha_hora_b = $_POST['fecha_hora_b'];
            $ubicacion_b = $_POST['ubicacion_b'];
            $resultado_b = $_POST['resultado_b'];
            $equipoL_b = $_POST['equipoL_b'];
            $equipoLoV_b = $_POST['equipoLoV_b'];
            $partidosB = new PartidosFutbol_modelo();
            $partidosB->insertar($fecha_hora_b, $ubicacion_b, $resultado_b, $equipoL_b, $equipoLoV_b);
            $data["titulo"] = "Ingresar nuevo partido";
            $this->mostrarPartidosB();
        }

        public function modificar($id_partido_b)
        {
            $partido = new PartidosBasketball_modelo();
            $dato["id_partido_b"] = $id_partido_b;
            $dato["partidobasketball"] = $partido->get_partidoB($id_partido_b);
            $dato["titulo"] = "Registro partidos";


            require_once "vista/deportes/basketball/basketball_Modificar.html";
        }

        public function actualizar()
        {
            $id_partido_b = $_POST['id_partido_b'];
            $fecha_hora_b = $_POST['fecha_hora_b'];
            $ubicacion_b = $_POST['ubicacion_b'];
            $resultado_b = $_POST['resultado_b'];
            $equipoL_b = $_POST['equipoL_b'];
            $equipoLoV_b = $_POST['equipoLoV_b'];
            $partidosB = new PartidosBasketball_modelo();
            $partidosB->modificar($id_partido_b, $fecha_hora_b, $ubicacion_b, $resultado_b, $equipoL_b, $equipoLoV_b);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosB();
        }

        public function eliminar($id_partido_b)
        {
            $partidosB = new PartidosBasketball_modelo();
            $partidosB->eliminar($id_partido_b);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosB();
        }
    }
?>