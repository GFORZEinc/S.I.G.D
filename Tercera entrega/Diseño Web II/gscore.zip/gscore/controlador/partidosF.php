<?php

    class PartidosFControlador  {
        public function __construct()
        {
            

            require_once "modelo/PartidosFutbolModelo.php";
        }

        public function mostrarPartidosF()
        {
            $partidosF = new PartidosFutbol_modelo();
            $data["titulo"] = "Partidos Registrados";
            $data["partidofutbol"] = $partidosF->get_partidosF();


            require_once "vista/deportes/futbol/futbol.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Partidos (FÚTBOL)";


            require_once "vista/deportes/futbol/futbol_Nuevos.html";
        }

        public function guardar()
        {
            $fecha_hora_f = $_POST['fecha_hora_f'];
            $ubicacion_f = $_POST['ubicacion_f'];
            $resultado_f = $_POST['resultado_f'];
            $equipoL_f = $_POST['equipoL_f'];
            $equipoLoV_f = $_POST['equipoLoV_f'];
            $partidosF = new PartidosFutbol_modelo();
            $partidosF->insertar($fecha_hora_f, $ubicacion_f, $resultado_f, $equipoL_f, $equipoLoV_f);
            $data["titulo"] = "Ingresar nuevo partido";
            $this->mostrarPartidosF();
        }

        public function modificar($id_partido_f)
        {
            $partido = new PartidosFutbol_modelo();
            $dato["id_partido_f"] = $id_partido_f;
            $dato["partidofutbol"] = $partido->get_partidoF($id_partido_f);
            $dato["titulo"] = "Registro partidos";


            require_once "vista/deportes/futbol/futbol_Modificar.html";
        }

        public function actualizar()
        {
            $id_partido_f = $_POST['id_partido_f'];
            $fecha_hora_f = $_POST['fecha_hora_f'];
            $ubicacion_f = $_POST['ubicacion_f'];
            $resultado_f = $_POST['resultado_f'];
            $equipoL_f = $_POST['equipoL_f'];
            $equipoLoV_f = $_POST['equipoLoV_f'];
            $partidosF = new PartidosFutbol_modelo();
            $partidosF->modificar($id_partido_f, $fecha_hora_f, $ubicacion_f, $resultado_f, $equipoL_f, $equipoLoV_f);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosF();
        }

        public function eliminar($id_partido_f)
        {
            $partidosF = new PartidosFutbol_modelo();
            $partidosF->eliminar($id_partido_f);
            $data["titulo"] = "Partido";
            $this->mostrarPartidosF();
        }
    }
?>