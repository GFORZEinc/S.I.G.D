<?php

    class EquiposControlador  {
        public function __construct()
        {
            

            require_once "modelo/EquiposModelo.php";
        }

        public function mostrarEquipos()
        {
            $equipos = new Equipos_modelo();
            $data["titulo"] = "Equipos Registrados";
            $data["equipo"] = $equipos->get_equipos();


            require_once "vista/equipos/equipos.html";
        }

        public function nuevo()
        {
            $data["titulo"] = "Registro de Equipos";


            require_once "vista/equipos/equipos_Nuevos.html";
        }

        public function guardar()
        {
            $nombreEquipo = $_POST['nombreEquipo'];
            $descriEquipo = $_POST['descriEquipo'];
            $equipos = new Equipos_modelo();
            $equipos->insertar($nombreEquipo, $descriEquipo);
            $data["titulo"] = "Ingresar nuevo equipo";
            $this->mostrarEquipos();
        }

        public function modificar($id)
        {
            $equipo = new Equipos_modelo();
            $dato["idequipo"] = $id;
            $dato["equipo"] = $equipo->get_equipo($id);
            $dato["titulo"] = "Registro equipos";


            require_once "vista/equipos/equipos_Modificar.html";
        }

        public function actualizar()
        {
            $id = $_POST['idequipo'];
            $nombreEquipo = $_POST['nombreEquipo'];
            $descriEquipo = $_POST['descriEquipo'];
            $equipo = new Equipos_modelo();
            $equipo->modificar($id, $nombreEquipo, $descriEquipo);
            $data["titulo"] = "Equipo";
            $this->mostrarEquipos();
        }

        public function eliminar($id)
        {
            $equipos = new Equipos_modelo();
            $equipos->eliminar($id);
            $data["titulo"] = "Equipo";
            $this->mostrarEquipos();
        }
    }
?>