<?php

    class UsuariosControlador
    {
        public function __construct()
        {
            

            require_once "modelo/LoginModelo.php";
        }

        public function mostrarUsuarios()
        {
            if($_SESSION['rol']!=1)
            {
				echo "La pagina no esta disponible";
			}
			$usuarios = new Login_modelo();
			$data["titulo"] = "Usuarios registrados";
			$data["usuarios"] = $usuarios->get_usuarios();
			

			require_once "vista/usuarios/usuarios_Agregar.html";	
        }

        public function nuevo()
        {
			$data["titulo"] = "Registro de usuarios";
			require_once "vista/usuarios/usuarios_Nuevos.html";
		}
        
        public function guardar()
        {
			$nombre = $_POST['nombre'];
			$apellido = $_POST['apellido'];
			$ci = $_POST['ci'];
			$usuario = $_POST['usuario'];
			$contra = $_POST['contra'];
			$correo = $_POST['correo'];
			$rol = $_POST['rol'];
			$usuarios = new Login_modelo();
			$usuarios->insertar($nombre, $apellido, $ci, $usuario, $contra, $correo, $rol );
			$data["titulo"] = "Ingresar nuevo usuario";
			$this->mostrarUsuarios();
		}

        public function modificar($idusuario)
        {
			$usuarios = new Login_modelo();
			$data["idusuario"] = $idusuario;
			$data["usuarios"] = $usuarios->get_usuario($idusuario);
			$data["titulo"] = "Modificar Usuario";


			require_once "vista/usuarios/usuarios_Modificar.html";
		}

        public function actualizar( )
        {
			$idusuario = $_POST['idusuario'];
			$nombre = $_POST['nombre'];
			$apellido = $_POST['apellido'];
			$ci = $_POST['ci'];
			$usuario = $_POST['usuario'];
			$contra = $_POST['contra'];
			$correo = $_POST['correo'];
			$rol = $_POST['rol'];
			$usuarios = new Login_modelo();
			$usuarios-> modificar($idusuario,$nombre, $apellido, $ci, $usuario, $contra, $correo, $rol);
			$data["titulo"] = "Usuarios";
			$this->mostrarUsuarios();
		}

        public function eliminar($idusuario)
        {
			$usuarios = new Login_modelo();
			$usuarios->eliminar($idusuario);
			$data["titulo"] = "Usuarios";
			$this->mostrarUsuarios();
		}	
    }
?>