<?php
	//Función para cargar el controlador recibe un string y devuelve unas instacia del controlar
	function cargarControlador(String $controlador): object{
		//ucwords convierte en mayuscula el primer caracter de la cadena.
		$nombreControlador = ucwords($controlador)."Controlador";
		$archivoControlador = 'controlador/'.ucwords($controlador).'.php';
		//Controlo si el archivo no exite cargue por defecto el controlador principal
		if(!is_file($archivoControlador)){
			
			$archivoControlador= 'controlador/'.CONTROLADOR_PRINCIPAL.'.php';
			
		}
		require_once $archivoControlador;
		$control = new $nombreControlador();
		return $control;
	}
	
	function cargarAccion($controlador, $accion, $id = null){
		/*La method_exists() función devuelve true si un objeto o una clase tiene un método específico. De lo contrario, vuelve false.*/
		if(isset($accion) && method_exists($controlador, $accion)){
			if($id == null){
				$controlador->$accion();
				} else {
					$controlador->$accion($id);
			}
			} else {
				$controlador->ACCION_PRINCIPAL();
		}	
	}
?>